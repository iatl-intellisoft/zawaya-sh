

from . import hr_contract
from . import hr_contract_line
from . import hr_salary_rule
from . import res_config_settings
from . import amount_to_ar
